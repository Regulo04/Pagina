let dados = [];

function generateTable(data) {
  if (!data || data.length === 0) {
    const mensagem = document.createElement("p");
    mensagem.textContent = "Nenhuma recomendação encontrada.";
    return mensagem;
  }

  const table = document.createElement("table");

  const columns = Object.keys(data[0]);

  const header = document.createElement("tr");

  columns.forEach(column => {
    const th = document.createElement("th");
    th.textContent = column;
    header.appendChild(th);
  });

  table.appendChild(header);

  data.forEach(item => {
    const row = document.createElement("tr");

    columns.forEach(column => {
      const cell = document.createElement("td");
      cell.textContent = item[column];
      row.appendChild(cell);
    });

    table.appendChild(row);
  });

  return table;
}

function atualizarTabela() {
  const filtros = [];

  if (document.getElementById("filtro_Tag_Controle").checked)
    filtros.push("controle");

  if (document.getElementById("filtro_Tag_TA").checked)
    filtros.push("ta");

  if (document.getElementById("filtro_Tag_QV").checked)
    filtros.push("qv");

  if (document.getElementById("filtro_Tag_InfoE").checked)
    filtros.push("info e");

  if (document.getElementById("filtro_Tag_InfoG").checked)
    filtros.push("info g");

  if (document.getElementById("filtro_Tag_InfoA").checked)
    filtros.push("info a");

  if (document.getElementById("filtro_Tag_Feedback").checked)
    filtros.push("feedback");

  let dadosFiltrados = dados;

  if (filtros.length > 0) {
    dadosFiltrados = dados.filter(item =>
      item.Tag &&
      filtros.some(filtro =>
        item.Tag.toLowerCase().includes(filtro)
      )
    );
  }

  const container = document.getElementById("tabela");

  container.innerHTML = "";
  container.appendChild(generateTable(dadosFiltrados));
}

async function loadTable() {
  try {
    const response = await fetch("dados/recomendacoes.json");

    dados = await response.json();

    atualizarTabela();
  } catch (erro) {
    console.error("Erro ao carregar JSON:", erro);
  }
}

// Registrar eventos para todos os filtros
[
  "filtro_Tag_Controle",
  "filtro_Tag_TA",
  "filtro_Tag_QV",
  "filtro_Tag_InfoE",
  "filtro_Tag_InfoG",
  "filtro_Tag_InfoA",
  "filtro_Tag_Feedback"
].forEach(id => {
  document
    .getElementById(id)
    .addEventListener("change", atualizarTabela);
});

loadTable();